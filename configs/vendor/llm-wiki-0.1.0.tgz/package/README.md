# llm-wiki

Tooling for LLM-maintained knowledge bases.

[![CI](https://github.com/simonplant/llm-wiki/actions/workflows/ci.yml/badge.svg)](https://github.com/simonplant/llm-wiki/actions/workflows/ci.yml)

Most people's experience with LLMs and documents looks like RAG: upload files, the LLM retrieves relevant chunks at query time, generates an answer. The LLM rediscovers knowledge from scratch on every question. Nothing accumulates. Nothing compounds.

[Andrej Karpathy's LLM Wiki pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) is different. Instead of retrieving from raw documents each time, the LLM **incrementally builds and maintains a persistent wiki** — a structured, interlinked collection of markdown files. When you add a new source, the LLM reads it, extracts the key information, and integrates it into the wiki: updating entity pages, revising summaries, noting contradictions, maintaining cross-references. The knowledge is compiled once and kept current.

The wiki is a persistent, compounding artifact. You never write it yourself — the LLM writes and maintains all of it. You curate sources, direct the analysis, and ask the right questions.

**llm-wiki** is the tooling that makes this work in practice. It handles scaffolding, validation, and file logistics so the LLM can focus on content. It embeds directly into your existing projects — one command and your agent is aware of the wiki.

## A practical example

Say you have an AI agent that helps you with multiple things: tracking personal goals, researching investment opportunities, planning meals, and doing deep dives on technical topics. Each of these needs its own knowledge base with its own structure.

### Setup (once)

```bash
# Install the tool
curl -sSL https://raw.githubusercontent.com/simonplant/llm-wiki/main/install.sh | bash

# Navigate to your agent's project
cd ~/dev/my-agent

# Create a knowledge base for each role
llm-wiki init --embed --name lifeops --domain personal --agent claude .
llm-wiki init --embed --name trading --domain due-diligence --agent claude .
llm-wiki init --embed --name nutrition --domain personal --agent claude .
llm-wiki init --embed --name research --domain research --agent claude .
```

After this, your project looks like:

```
my-agent/
├── CLAUDE.md                          # your existing file + wiki instructions appended
├── .claude/
│   ├── commands/
│   │   ├── wiki-lifeops-ingest.md     # /wiki-lifeops-ingest
│   │   ├── wiki-lifeops-query.md      # /wiki-lifeops-query
│   │   ├── wiki-lifeops-review.md     # /wiki-lifeops-review
│   │   ├── wiki-trading-ingest.md     # /wiki-trading-ingest
│   │   ├── wiki-trading-query.md      # ... and so on
│   │   └── ...                        # 12 skills total (3 per KB)
│   └── settings.json                  # session-start hook merged in
└── knowledge/
    ├── lifeops/                        # Goals, Reflections, Habits
    │   ├── raw/   wiki/   index.md   log.md
    ├── trading/                        # Companies, Markets, Risks
    │   ├── raw/   wiki/   index.md   log.md
    ├── nutrition/                      # Goals, Habits, Resources
    │   ├── raw/   wiki/   index.md   log.md
    └── research/                       # Literature, Methods, Findings
        ├── raw/   wiki/   index.md   log.md
```

Your CLAUDE.md now tells the agent about all four knowledge bases — when to check them, when to add to them, how they're structured.

### Daily use: adding sources

You read an article about portfolio rebalancing strategies. Save it as markdown and stage it:

```bash
llm-wiki ingest ~/articles/rebalancing-strategies.md --name trading
```

This copies the file into `knowledge/trading/raw/`, extracts the title from frontmatter, and adds a stub to the trading index. Then open your agent:

```
You: /wiki-trading-ingest

Agent: I see 1 unprocessed source in knowledge/trading/raw/:
  - rebalancing-strategies.md — "Tax-Efficient Rebalancing Strategies"

Key takeaways:
  1. Tax-loss harvesting during rebalancing can offset 1-2% annually
  2. Threshold-based rebalancing outperforms calendar-based
  3. ...

Want me to emphasize any particular aspect?

You: focus on the tax implications, and cross-reference with our existing pages on AAPL and NVDA

Agent: Created:
  - wiki/rebalancing-strategies.md (source summary)
  - wiki/tax-loss-harvesting.md (new concept page)
Updated:
  - wiki/apple.md — added rebalancing context
  - wiki/nvidia.md — added rebalancing context
  - index.md — 2 new entries under Concepts
  - log.md — ingest entry appended
```

### Daily use: asking questions

Later, you want to understand something across your knowledge:

```
You: /wiki-trading-query
     What's my total exposure to semiconductor risk across all positions?

Agent: Based on the trading wiki:

According to [[nvidia]], you hold 150 shares acquired at $450 (see [[Portfolio Snapshot Q4]]).
[[apple]] has significant semiconductor dependency through the M-series chips
(see [[Apple Supply Chain]]).
[[semiconductor-market]] notes current TSMC concentration risk...

This analysis touches 4 pages. Want me to file it as a Comparisons page
so it stays in the wiki?
```

### Daily use: health checks

Every few sessions, review the wiki:

```
You: /wiki-trading-review

Agent: Content review of trading wiki (12 pages, 5 sources):

Fix now:
  - [[nvidia]] says Q3 revenue was $18B but [[Q3 Earnings]] says $18.1B — minor
    discrepancy, should align on the primary source

Improve:
  - [[apple]] and [[nvidia]] both mention TSMC but don't link to each other
  - [[portfolio-snapshot-q4]] has no inbound links — orphaned

Investigate:
  - No page on interest rate exposure — relevant given recent Fed activity
  - The rebalancing analysis from last session could be expanded with
    historical data

Want me to fix the cross-references and create an interest rate page?
```

### Checking wiki health from the CLI

```bash
# Quick briefing (also runs automatically at session start)
llm-wiki context

# Structural validation
llm-wiki lint --fix --name trading

# Full setup check
llm-wiki doctor

# What changed since last session
llm-wiki diff
```

### The session-start experience

When you open Claude Code in this project, the SessionStart hook automatically runs `llm-wiki context`, injecting something like:

```
# Wiki Context

4 knowledge bases: lifeops, nutrition, research, trading

---

## trading

12 pages, 5 sources.

### Unprocessed sources (1)

- raw/fed-minutes-march.md — Federal Reserve March Meeting Minutes

### Structural issues (2, 2 fixable)

- index-missing: 1
- orphan-page: 1

### Wiki contents

**Companies** (3): apple, nvidia, tsmc
**Markets** (2): semiconductors, interest-rates
**Risks** (1): tsmc-concentration

Top connected: nvidia (5), apple (4)
```

The agent knows the wiki state from message one. No wasted turns.

## How it works

The pattern has three layers, three operations, and two navigation files:

**Three layers**: raw sources (your documents, immutable) → wiki (LLM-generated pages with `[[wiki links]]`) → schema (CLAUDE.md instructions that make the LLM a disciplined maintainer)

**Three operations**: ingest (process sources into wiki pages) → query (ask questions, get grounded answers) → lint (health-check for contradictions and gaps)

**Two navigation files**: index.md (catalog of all pages by category) + log.md (chronological record of operations)

The tool provides two interfaces:

| | CLI (any agent) | Skills (Claude Code) |
|---|-----------------|---------------------|
| **Ingest** | `llm-wiki ingest` — stage files | `/wiki-ingest` — full workflow |
| **Query** | — | `/wiki-query` — find, synthesize, file |
| **Lint** | `llm-wiki lint` — structural | `/wiki-review` — content |
| **Health** | `context`, `doctor`, `stats`, `diff` | Session-start hook |

The CLI handles mechanics (deterministic, any agent). Skills handle LLM work (interactive, Claude Code). Skills are optional — the CLI works with any agent.

## Install

```bash
curl -sSL https://raw.githubusercontent.com/simonplant/llm-wiki/main/install.sh | bash
```

Customize with `--domain` and `--agent`:

```bash
# A research wiki for Claude Code
curl ... | bash -s -- --domain research --agent claude

# A book reading companion for any agent
curl ... | bash -s -- --domain book --agent both

# A team knowledge base for Codex
curl ... | bash -s -- --domain business --agent codex
```

## Commands

```
llm-wiki init      [--embed] [--name <kb>] [--domain <type>] [--agent <type>] [--git] [path]
llm-wiki ingest    <source-files...> [--name <kb>]
llm-wiki lint      [--fix] [--json] [--name <kb>]
llm-wiki stats     [--name <kb>]
llm-wiki context
llm-wiki doctor
llm-wiki diff      [--since <date>]
llm-wiki upgrade   [--domain <type>] [--agent <type>]
```

All commands auto-detect the wiki. Use `--name` to target a specific knowledge base in multi-KB setups.

## Domain templates

| Template | Categories | For |
|----------|-----------|-----|
| `generic` | Entities, Concepts, Sources, Analyses | General purpose (default) |
| `research` | Literature, Concepts, Methods, Findings, Open Questions | Paper synthesis, literature reviews |
| `book` | Characters, Themes, Plot, Chapters, Quotes, Places | Reading companions |
| `personal` | Goals, Reflections, People, Habits, Resources | Life tracking, self-improvement |
| `business` | Projects, People, Decisions, Meetings, Customers | Team knowledge |
| `due-diligence` | Companies, Markets, Risks, Comparisons | Investment research, competitive analysis |

## Docs

- [`docs/product.md`](docs/product.md) — product vision, deployment models, principles
- [`docs/architecture.md`](docs/architecture.md) — tool architecture, multi-KB, schema generation
- [`docs/karpathy-llm-wiki.md`](docs/karpathy-llm-wiki.md) — Karpathy's original idea file

## License

Apache 2.0
